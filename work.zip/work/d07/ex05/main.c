/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 16:06:03 by spiro             #+#    #+#             */
/*   Updated: 2016/08/17 16:06:06 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	**ft_split_whitespaces(char *str);

int		main(void)
{
	int i;
	char *string = "this    is 	 testing ";
	char **words = ft_split_whitespaces(string);
	
	i = 0;
	while (words[i] != 0)
	{
		printf ("%s ", words[i]);
		printf ("\n");
		i++;
	}

    return (0);
}
