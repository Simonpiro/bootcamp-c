/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_words_tables.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/18 22:17:31 by spiro             #+#    #+#             */
/*   Updated: 2016/08/18 22:21:56 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print_words_tables(char **tab)
{
	int	x;
	int	i;

	x = 0;
	i = 0;
	while (tab[i] != 0)
	{
		while (tab[i][x] != '\0')
		{
			ft_putchar(tab[i][x]);
			x++;
		}
		ft_putchar('\n');
		x = 0;
		i++;
	}
}
