/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 16:06:03 by spiro             #+#    #+#             */
/*   Updated: 2016/08/17 16:06:06 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_ultimate_range(int **range, int min, int max);

int		main(void)
{
	int i;
	int min;
	int max;
	int *numbers;

	i = 0;
	min = -5;
	max = 6;
	ft_ultimate_range(&numbers, min, max);
	while (i < (max-min))
	{
		printf ("%d ", numbers[i]);
		i++;
	}
	printf("\n %d", ft_ultimate_range(&numbers, min, max));

    return (0);
}
