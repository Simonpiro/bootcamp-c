/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 16:06:03 by spiro             #+#    #+#             */
/*   Updated: 2016/08/17 16:06:06 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strdup(char *src);

int		main(void)
{
	char *str1 = "world";
    char *str2;
    str2 = ft_strdup(str1);
 
    printf("Duplicated string is : %s", str2);
    return (0);
}
