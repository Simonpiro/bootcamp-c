/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 16:06:03 by spiro             #+#    #+#             */
/*   Updated: 2016/08/18 13:08:25 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	*ft_range(int min, int max);

int		main(void)
{
	int i;
	int min;
	int max;
	int *numbers;

	i = 0;
	min = -214748;
	max = 21474;
	numbers = ft_range(min, max);
	while (i < (max-min))
	{
		printf ("%d ", numbers[i]);
		i++;
	}

    return (0);
}
