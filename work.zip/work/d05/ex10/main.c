/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 10:22:35 by spiro             #+#    #+#             */
/*   Updated: 2016/08/16 08:31:46 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *c);
char	*ft_strcapitalize(char *str);

int main(void)
{
	//char str1[] = "test. something 42test; second+test   last test";
	char str1[] = "salut, comment tu vas ? 42Mots quarante-deux; cinquante+et+un";
	ft_putstr(ft_strcapitalize(str1));
	return(0);
}
