/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 10:22:35 by spiro             #+#    #+#             */
/*   Updated: 2016/08/16 08:31:46 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *c);
char	*ft_strncat(char *dest, char *src, int nb);

int main(void)
{
	char str1[] = "Hello";
	char str2[] = " World";
	ft_putstr(ft_strncat(str1, str2, 3));
	return(0);
}