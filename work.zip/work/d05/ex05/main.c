/* ************************************************************************** */

/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 10:22:35 by spiro             #+#    #+#             */
/*   Updated: 2016/08/15 11:41:16 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putstr(char *str);
char	*ft_strstr(char *str, char *to_find);

int main(void)
{
	char short_str[] = "abcd";
	char long_str[] = "looking for here";
	ft_putstr(ft_strstr(long_str, short_str));
	return(0);
}
