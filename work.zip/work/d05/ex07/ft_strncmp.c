/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 18:03:22 by spiro             #+#    #+#             */
/*   Updated: 2016/08/16 15:53:06 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	int				i;
	unsigned char	a;
	unsigned char	b;

	i = 0;
	while ((s1[i] != '\0' || s2[i] != '\0') && i < n)
	{
		a = s1[i];
		b = s2[i];
		if (a > b || b == '\0')
			return (a - b);
		else if (a < b)
			return (a - b);
		i++;
	}
	if (s1[i] < s2[i])
	{
		a = s1[i];
		b = s2[i];
		return (a - b);
	}
	return (0);
}
