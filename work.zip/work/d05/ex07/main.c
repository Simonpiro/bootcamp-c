/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 10:22:35 by spiro             #+#    #+#             */
/*   Updated: 2016/08/15 20:31:02 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int i);
int		ft_strncmp(char *s1, char *s2, unsigned int n);

int main(void)
{
	char *str1 = "ABCDEFGHIJK";
	char *str2 = "ABCD";
	ft_putnbr(ft_strncmp(str1, str2, 5));
	return(0);
}
