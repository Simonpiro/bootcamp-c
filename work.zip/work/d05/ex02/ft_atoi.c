/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 10:16:27 by spiro             #+#    #+#             */
/*   Updated: 2016/08/16 15:37:47 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_atoi(char *str)
{
	int i;
	int number;
	int sign;
	int c;

	number = 0;
	c = 0;
	i = str[0] == 43 ? 1 : 0;
	while (str[i] != '\0')
	{
		if ((str[i] <= 32 || str[i] == '\r') && number == 0)
			c++;
		else if ((str[c + 1] < 48 || str[c + 1] > 57) && str[c] == 45)
			return (0);
		else if ((str[i] >= 48 && str[i] < 58) || str[c] == 45)
		{
			if ((str[i] >= 48 && str[i] < 58))
				number = 10 * number + (str[i] - 48);
		}
		else
			break ;
		i++;
	}
	sign = str[c] == 45 ? -1 : 1;
	return (number * sign);
}
