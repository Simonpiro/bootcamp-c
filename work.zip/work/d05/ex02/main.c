/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 09:20:58 by spiro             #+#    #+#             */
/*   Updated: 2016/08/15 14:44:55 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_atoi(char * str);
void	ft_putchar(char c);
void	ft_putnbr(int i);

int main(void)
{
	ft_putnbr(ft_atoi("2147483648"));
	ft_putchar('\n');
	ft_putnbr(ft_atoi("21hello"));
	ft_putchar('\n');
	ft_putnbr(ft_atoi("21"));
	ft_putchar('\n');
	ft_putnbr(ft_atoi("+-45"));
	ft_putchar('\n');
	ft_putnbr(ft_atoi("-33"));
	return (0);
}
