/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 10:22:35 by spiro             #+#    #+#             */
/*   Updated: 2016/08/16 08:31:46 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void			ft_putnbr(int n);
unsigned int	ft_strlcat(char *dest, char *src, unsigned int size);

int main(void)
{
	char str1[8] = "Hello";
	char str2[6] = "World";
	ft_putnbr(ft_strlcat(str1, str2, 8));
	return(0);
}