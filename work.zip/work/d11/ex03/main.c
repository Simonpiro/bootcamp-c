/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 14:38:50 by spiro             #+#    #+#             */
/*   Updated: 2016/08/23 14:44:31 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <unistd.h>
#include <stdio.h>

void	ft_list_push_back(t_list **begin_list, void *data);
void	ft_list_push_front(t_list **begin_list, void *data);
int		ft_list_size(t_list *begin_list);

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
}

int		main()
{
	t_list *list;
	int i;

	list = NULL;
	ft_list_push_back(&list, "first\n");
	ft_list_push_back(&list, "second\n");
	ft_list_push_back(&list, "third\n");
	ft_list_push_front(&list, "last\n");
	ft_list_push_front(&list, "latest\n");
	printf("%d", ft_list_size(list));
	while(list)
	{
		ft_putstr(list->data);
		list = list->next;
	}
	printf("%d", ft_list_size(list));
	return (0);
}
