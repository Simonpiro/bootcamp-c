/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_params.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/24 10:49:22 by spiro             #+#    #+#             */
/*   Updated: 2016/08/24 10:49:27 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list		*ft_list_push_params(int ac, char **av)
{
	t_list	*new;
	t_list	*previous;
	int		i;

	i = 0;
	previous = NULL;
	while (i < ac)
	{
		new = ft_create_elem(av[i]);
		if (previous != NULL)
		{
			new->next = previous;
		}
		previous = new;
		i++;
	}
	return (new);
}
