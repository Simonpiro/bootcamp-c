/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 14:38:50 by spiro             #+#    #+#             */
/*   Updated: 2016/08/23 17:55:35 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"
#include <unistd.h>
#include <stdio.h>

void	ft_list_push_back(t_list **begin_list, void *data);
void	ft_list_push_front(t_list **begin_list, void *data);
t_list	*ft_list_at(t_list *begin_list, unsigned int nbr);

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
	{
		ft_putchar(str[i]);
		i++;
	}
}

int		main()
{
	t_list *list;
	int i;
	t_list *c;
	t_list *v;

	list = NULL;
	c = NULL;
	ft_list_push_back(&list, "first\n");
	ft_list_push_back(&list, "second\n");
	ft_list_push_back(&list, "third\n");
	ft_list_push_front(&list, "last\n");
	ft_list_push_front(&list, "latest\n");
	ft_list_push_back(&list, "fourth\n");
	c = ft_list_at(list , 3);
	printf("%s", c->data);
	return (0);
}
