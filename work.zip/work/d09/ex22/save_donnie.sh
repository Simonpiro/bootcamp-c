alias rm="echo Donnie Saved!"
