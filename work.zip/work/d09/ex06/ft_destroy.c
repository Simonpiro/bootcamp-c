/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_destroy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/19 08:29:37 by spiro             #+#    #+#             */
/*   Updated: 2016/08/19 09:04:52 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_ultimator.h"

void	ft_destroy(char ***factory)
{
	int	x;
	int	y;

	x = 0;
	y = 0;
	while (factory[x])
	{
		while (factory[x][y])
		{
			free(factory[x][y]);
			y++;
		}
		y = 0;
		free(factory[x]);
		x++;
	}
	free(factory);
}
