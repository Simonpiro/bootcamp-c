#!/bin/bash

str=$(ifconfig -a | awk '/inet / {print $2}' | awk 'NR>1')
if [[ $str ]]; then
	echo $str
else
	echo "Je suis perdu!"
fi