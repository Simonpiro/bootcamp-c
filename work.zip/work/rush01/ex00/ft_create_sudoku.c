/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_sudoku.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 21:20:25 by spiro             #+#    #+#             */
/*   Updated: 2016/08/21 21:20:29 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_sudoku.h"

char		**ft_create_sudoku(int argc, char **argv)
{
	char	**sudoku;
	int		i;
	int		j;

	i = 0;
	j = 0;
	sudoku = (char**)malloc(sizeof(char*) * 10);
	while (i < argc)
	{
		sudoku[i] = (char*)malloc(sizeof(char) * 10);
		while (j < argc)
		{
			if (argv[i][j] == '\0' || ((argv[i][j] < '1'
				|| argv[i][j] > '9') && argv[i][j] != '.'))
				return (0);
			sudoku[i][j] = argv[i][j];
			j++;
		}
		sudoku[i][j] = '\0';
		j = 0;
		i++;
	}
	sudoku[i] = 0;
	return (sudoku);
}
