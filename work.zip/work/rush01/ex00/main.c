/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/20 18:43:26 by spiro             #+#    #+#             */
/*   Updated: 2016/08/20 18:43:40 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_sudoku.h"

int			main(int argc, char **argv)
{
	char	**sudoku;
	char	**solution;
	int		interface;

	interface = 0;
	if (argc == 10)
	{
		sudoku = ft_create_sudoku(argc - 1, &argv[1]);
		solution = ft_create_sudoku(argc - 1, &argv[1]);
		if (sudoku != 0)
		{
			if (ft_solve_sudoku(solution, sudoku, 0, 0) == 1)
			{
				if (interface == 1)
					ft_print_nice_sudoku(solution);
				else
					ft_print_sudoku(solution);
				return (0);
			}
		}
	}
	ft_putstr("Error\n");
	return (0);
}
