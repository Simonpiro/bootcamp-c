/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sudoku.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 12:25:33 by spiro             #+#    #+#             */
/*   Updated: 2016/08/21 12:26:12 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SUDOKU_H
# define FT_SUDOKU_H
# include <unistd.h>
# include <stdlib.h>

void	ft_putchar(char c);
void	ft_putstr(char *str);
void	ft_print_sudoku(char **sudoku);
void	ft_print_nice_sudoku(char **sudoku);
char	**ft_create_sudoku(int argc, char **argv);
int		ft_solve_sudoku(char **solution, char **sudoku, int m, int l);
#endif
