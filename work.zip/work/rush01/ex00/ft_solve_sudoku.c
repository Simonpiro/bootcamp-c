/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_solve_sudoku.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mfilipch <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 12:23:18 by mfilipch          #+#    #+#             */
/*   Updated: 2016/08/21 12:23:20 by mfilipch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_sudoku.h"

int		ft_checkcell(char **sudoku, int i, int j, int k)
{
	int l;
	int m;

	l = 0;
	m = 0;
	while (l++ < 9)
		if (l - 1 != j && sudoku[i][l - 1] == k + '0')
			return (0);
	while (m++ < 9)
		if (m - 1 != i && sudoku[m - 1][j] == k + '0')
			return (0);
	m = (i / 3) * 3;
	while ((m++ / 3) == (i / 3))
	{
		l = (j / 3) * 3;
		while ((l++ / 3) == (j / 3))
			if (m - 1 != i && l - 1 != j && sudoku[m - 1][l - 1] == k + '0')
				return (0);
	}
	return (1);
}

void	ft_copysudoku(char **sudoku1, char **sudoku2)
{
	int i;
	int j;

	i = 0;
	while (sudoku2[i])
	{
		j = 0;
		while (sudoku2[i][j])
		{
			sudoku1[i][j] = sudoku2[i][j];
			j++;
		}
		i++;
	}
}

int		ft_solve_sudoku(char **sol, char **sudoku, int m, int l)
{
	int k;
	int nsol;

	while (m++ < 9)
	{
		l = 0;
		while (l++ < 9)
			if (sudoku[m - 1][l - 1] == '.')
			{
				k = 0;
				nsol = 0;
				while (k++ < 9)
					if (ft_checkcell(sudoku, m - 1, l - 1, k) == 1)
					{
						sudoku[m - 1][l - 1] = k + '0';
						nsol += ft_solve_sudoku(sol, sudoku, m - 1, l - 1);
						sudoku[m - 1][l - 1] = '.';
						if (nsol > 1)
							return (nsol);
					}
				return (nsol);
			}
	}
	ft_copysudoku(sol, sudoku);
	return (1);
}
