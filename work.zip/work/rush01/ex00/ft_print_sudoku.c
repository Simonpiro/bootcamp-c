/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_sudoku.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/21 12:42:57 by spiro             #+#    #+#             */
/*   Updated: 2016/08/21 12:43:10 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_sudoku.h"

void	ft_print_sudoku(char **sudoku)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (sudoku[i] != 0)
	{
		while (sudoku[i][j] != '\0')
		{
			ft_putchar(sudoku[i][j]);
			if (j != 8)
				ft_putchar(' ');
			j++;
		}
		ft_putchar('\n');
		j = 0;
		i++;
	}
}

void	ft_print_nice_sudoku(char **sudoku)
{
	int i;
	int j;

	i = 0;
	j = 0;
	ft_putstr("        S  U  D  O  K  U\n-------------------------------\n");
	while (sudoku[i] != 0)
	{
		ft_putchar('|');
		while (sudoku[i][j] != '\0')
		{
			ft_putchar(' ');
			ft_putchar(sudoku[i][j]);
			ft_putchar(' ');
			if (j == 2 || j == 5)
				ft_putchar('|');
			j++;
		}
		ft_putstr("|\n");
		if (i == 2 || i == 5)
			ft_putstr("-------------------------------\n");
		j = 0;
		i++;
	}
	ft_putstr("-------------------------------\n");
}
