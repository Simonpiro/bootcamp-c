#!/bin/bash

ldapwhoami -Q | cut -c 4-
