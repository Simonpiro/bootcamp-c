/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/13 15:37:53 by spiro             #+#    #+#             */
/*   Updated: 2016/08/14 16:51:20 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char x);

void	rush(int x, int y)
{
	int width;
	int height;

	width = x;
	height = y;
	while (height > 0)
	{
		while (width > 0)
		{
			if ((width == x && height == y) || (width == 1 && height == 1))
				ft_putchar('A');
			else if ((width == x && height == 1) || (width == 1 && height == y))
				ft_putchar('C');
			else if (width == 1 || width == x || height == 1 || height == y)
				ft_putchar('B');
			else
				ft_putchar(' ');
			width--;
		}
		ft_putchar('\n');
		width = x;
		height--;
	}
}
