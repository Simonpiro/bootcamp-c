/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calc.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elee <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 17:48:23 by elee              #+#    #+#             */
/*   Updated: 2016/08/27 17:48:38 by elee             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		calc_length(t_list *list)
{
	int	length;

	if (list == NULL)
		return (0);
	length = 0;
	while (list->data != '\n')
	{
		length++;
		list = list->next;
	}
	return (length);
}

int		calc_newline(t_list *list)
{
	int	count;

	count = 0;
	while (list)
	{
		if (list->data == '\n')
			count++;
		list = list->next;
	}
	return (count);
}

int		calc_area(t_list *list)
{
	int	area;
	int	count_newline;

	count_newline = calc_newline(list);
	area = 0;
	while (list)
	{
		area++;
		list = list->next;
	}
	area -= count_newline;
	return (area);
}

int		calc_height(t_list *list)
{
	int	height;

	if (list == NULL)
		return (0);
	height = calc_area(list) / calc_length(list);
	return (height);
}
