/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 08:33:04 by spiro             #+#    #+#             */
/*   Updated: 2016/08/28 21:52:33 by elee             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_check_rush(int rush_num, int length, int height, t_list *list)
{
	t_list	*compare;

	compare = rush(rush_num, length, height);
	while (list && compare)
	{
		if (list->data != compare->data)
		{
			ft_list_clear(&compare);
			return (0);
		}
		list = list->next;
		compare = compare->next;
	}
	ft_list_clear(&compare);
	return (1);
}

int		ft_count_rush(int length, int height, t_list *list)
{
	int		count;
	int		index;

	count = 0;
	index = 0;
	while (index < 5)
	{
		if (ft_check_rush(index, length, height, list))
			count++;
		index++;
	}
	return (count);
}

void	print_part(int index, int length, int height)
{
	ft_putstr("[rush-0");
	ft_putnbr(index);
	ft_putstr("] [");
	ft_putnbr(length);
	ft_putstr("] [");
	ft_putnbr(height);
	ft_putchar(']');
}

void	print_rush(t_list *list, int length, int height)
{
	int index;
	int total;
	int count;

	index = 0;
	total = ft_count_rush(length, height, list);
	count = 0;
	while (index < 5)
	{
		if (ft_check_rush(index, length, height, list))
		{
			print_part(index, length, height);
			count++;
			if (count < total)
				ft_putstr(" || ");
		}
		index++;
	}
	if (count == 0)
		ft_putstr("No matching rush found.");
}

int		main(void)
{
	char	buf;
	int		ret;
	t_list	*list;

	list = NULL;
	while ((ret = read(0, &buf, 1)))
		ft_list_push_back(&list, buf);
	print_rush(list, calc_length(list), calc_height(list));
	ft_detect_shape(list);
	ft_putchar('\n');
	ft_list_clear(&list);
	return (0);
}
