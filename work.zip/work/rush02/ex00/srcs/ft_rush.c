/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rush.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elee <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 15:39:30 by elee              #+#    #+#             */
/*   Updated: 2016/08/27 15:59:18 by elee             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"
#include "ft_rush.h"

void	put(t_list **list, int ct[2], int par[2], char print[10])
{
	if (ct[0] == 1 && ct[1] == 1)
		ft_list_push_back(list, print[0]);
	else if (ct[0] > 1 && ct[0] < par[0] && ct[1] == 1)
		ft_list_push_back(list, print[1]);
	else if (ct[0] == par[0] && ct[1] == 1)
		ft_list_push_back(list, print[2]);
	else if (ct[0] == 1 && ct[1] > 1 && ct[1] < par[1])
		ft_list_push_back(list, print[3]);
	else if (ct[0] > 1 && ct[0] < par[0] && ct[1] > 1 && ct[1] < par[1])
		ft_list_push_back(list, print[4]);
	else if (ct[0] == par[0] && ct[1] > 1 && ct[1] < par[1])
		ft_list_push_back(list, print[5]);
	else if (ct[0] == 1 && ct[1] == par[1])
		ft_list_push_back(list, print[6]);
	else if (ct[0] > 1 && ct[0] < par[0] && ct[1] == par[1])
		ft_list_push_back(list, print[7]);
	else
		ft_list_push_back(list, print[8]);
	if (ct[0] == par[0])
		ft_list_push_back(list, '\n');
}

t_list	*rush(int rush_num, int x, int y)
{
	int		ct[2];
	int		par[2];
	t_list	*list;

	ct[0] = 1;
	ct[1] = 1;
	par[0] = x;
	par[1] = y;
	list = NULL;
	while (ct[1] <= par[1])
	{
		ct[0] = 1;
		while (ct[0] <= par[0])
		{
			put(&list, ct, par, g_rush[rush_num].print_char);
			ct[0]++;
		}
		ct[1]++;
	}
	return (list);
}
