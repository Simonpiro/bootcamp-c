/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_detect.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/28 11:48:27 by spiro             #+#    #+#             */
/*   Updated: 2016/08/28 21:52:54 by elee             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_detect_rectangle(t_list *list)
{
	int	length_first;
	int	length_current;

	if (list == NULL)
		return (0);
	length_first = calc_length(list);
	length_current = 0;
	while (list)
	{
		length_current++;
		if (list->data == '\n')
		{
			if ((length_current - 1) != length_first)
				return (0);
			else
				length_current = 0;
		}
		list = list->next;
	}
	return (1);
}

int		ft_detect_square(t_list *list)
{
	if ((ft_detect_rectangle(list) == 1) &&
		(calc_length(list) == calc_height(list)))
		return (1);
	return (0);
}

void	ft_print_shape(char *shape, int length, int height)
{
	ft_putstr(" || [");
	ft_putstr(shape);
	ft_putstr("] [");
	ft_putnbr(length);
	ft_putstr("] [");
	ft_putnbr(height);
	ft_putstr("]");
}

void	ft_detect_shape(t_list *list)
{
	if (ft_detect_rectangle(list))
	{
		ft_print_shape("rectangle", calc_length(list), calc_height(list));
	}
	if (ft_detect_square(list))
	{
		ft_print_shape("square", calc_length(list), calc_height(list));
	}
}
