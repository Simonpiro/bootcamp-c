/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_put_func.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: elee <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/27 18:27:19 by elee              #+#    #+#             */
/*   Updated: 2016/08/27 18:43:19 by elee             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putstr(char *str)
{
	while (*str)
	{
		ft_putchar(*str);
		str++;
	}
}

void	ft_putnbr(int nb)
{
	int		i;
	int		mod;
	char	revstr[10];

	i = 0;
	if (nb >= -2147483648 && nb <= 2147483647)
	{
		if (nb < 0)
			ft_putchar('-');
		if (nb == 0)
			ft_putchar('0');
		while (nb != 0)
		{
			mod = nb % 10;
			if (mod < 0)
				mod *= -1;
			revstr[i] = mod;
			nb /= 10;
			i++;
		}
		while (--i != -1)
			ft_putchar(revstr[i] + '0');
	}
}
