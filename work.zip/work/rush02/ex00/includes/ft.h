/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/20 10:49:32 by spiro             #+#    #+#             */
/*   Updated: 2016/08/28 21:51:01 by elee             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <unistd.h>
# include <stdlib.h>

void				ft_putchar(char c);
void				ft_putstr(char *str);
void				ft_putnbr(int nb);
typedef struct		s_list
{
	struct s_list	*next;
	char			data;
}					t_list;

void				ft_list_push_back(t_list **begin_list, char data);
void				ft_list_clear(t_list **begin_list);
int					calc_length(t_list *list);
int					calc_newline(t_list *list);
int					calc_area(t_list *list);
int					calc_height(t_list *list);
void				ft_detect_shape(t_list *list);
t_list				*rush(int rush_num, int x, int y);

#endif
