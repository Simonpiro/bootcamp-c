#!/bin/sh

./test 2 1 3 | ./rush-2 | cat -e
./test 3 1 3 | ./rush-2 | cat -e
./test 3 5 1 | ./rush-2 | cat -e
./test 0 0 0 | ./rush-2 | cat -e
./test 0 -1 -1 | ./rush-2 | cat -e
./test 0 -1 0 | ./rush-2 | cat -e
./test 0 0 -1 | ./rush-2 | cat -e
./test 4 1 3 | ./rush-2 | cat -e
./test 4 4 4 | ./rush-2 | cat -e
./test 1 1 1 | ./rush-2 | cat -e
