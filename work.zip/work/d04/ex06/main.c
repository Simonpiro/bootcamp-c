/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/13 13:56:59 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int x);
int		ft_is_prime(int index);
void	ft_putchar(char v);

int main()
{
	int x;

	x = 0;
	x = ft_is_prime(23);
	ft_putnbr(x);
	ft_putnbr(ft_is_prime(2147483642));
	ft_putnbr(ft_is_prime(0));
	ft_putnbr(ft_is_prime(1));
	ft_putnbr(ft_is_prime(23));
	return(0);
}
