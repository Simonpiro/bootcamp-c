/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 15:21:25 by spiro             #+#    #+#             */
/*   Updated: 2016/08/12 15:51:37 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_recursive_factorial(int nb)
{
	int i;
	int fac;

	i = nb;
	fac = nb;
	if (nb <= 0 || nb > 12)
		return (0);
	if (i > 1)
	{
		fac = fac * ft_recursive_factorial(i - 1);
		i--;
	}
	return (fac);
}
