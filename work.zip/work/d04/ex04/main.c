/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/13 08:55:29 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int x);
int		ft_fibonacci(int index);
void	ft_putchar(char v);

int main()
{
	int x;

	x = 0;
	x = ft_fibonacci(5);
	ft_putnbr(x);
	ft_putnbr(ft_fibonacci(6));
	ft_putnbr(ft_fibonacci(7));
	ft_putnbr(ft_fibonacci(-5));
	return(0);
}
