/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/13 13:30:29 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int x);
int		ft_sqrt(int index);
void	ft_putchar(char v);

int main()
{
	int x;

	x = 0;
	x = ft_sqrt(25);
	ft_putnbr(x);
	ft_putnbr(ft_sqrt(2147483642));
	ft_putnbr(ft_sqrt(0));
	ft_putnbr(ft_sqrt(-5));
	ft_putnbr(ft_sqrt(36));
	return(0);
}
