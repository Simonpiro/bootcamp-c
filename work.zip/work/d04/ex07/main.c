/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/13 14:19:47 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int x);
int		ft_find_next_prime(int index);
void	ft_putchar(char v);

int main()
{
	int x;

	x = 0;
	x = ft_find_next_prime(23);
	ft_putnbr(x);
	//ft_putnbr(ft_is_prime(2147483642));
	ft_putnbr(ft_find_next_prime(2));
	ft_putnbr(ft_find_next_prime(4));
	ft_putnbr(ft_find_next_prime(21));
	return(0);
}
