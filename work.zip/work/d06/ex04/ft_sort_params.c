/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 08:17:19 by spiro             #+#    #+#             */
/*   Updated: 2016/08/17 09:31:14 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print_arguments(int number, char **arguments)
{
	int	i;
	int x;

	x = 1;
	i = 0;
	while (x < number)
	{
		while (arguments[x][i] != '\0')
		{
			ft_putchar(arguments[x][i]);
			i++;
		}
		ft_putchar('\n');
		i = 0;
		x++;
	}
}

int		ft_strcmp(char *s1, char *s2)
{
	int				i;
	unsigned char	a;
	unsigned char	b;

	i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		a = s1[i];
		b = s2[i];
		if (a > b || b == '\0')
			return (a - b);
		else if (a < b)
			return (a - b);
		i++;
	}
	return (0);
}

int		main(int argc, char **argv)
{
	int		i;
	int		j;
	char	*tmp;

	i = 1;
	j = 1;
	while (i < (argc - 1))
	{
		while (j < (argc - 1))
		{
			if (ft_strcmp(argv[j], argv[j + 1]) > 0)
			{
				tmp = argv[j];
				argv[j] = argv[j + 1];
				argv[j + 1] = tmp;
			}
			j++;
		}
		j = 1;
		i++;
	}
	ft_print_arguments(argc, argv);
	return (0);
}
