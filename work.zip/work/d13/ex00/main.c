/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/26 11:07:31 by spiro             #+#    #+#             */
/*   Updated: 2016/08/26 11:09:24 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdio.h>

t_btree		*btree_create_node(void *item);

int			main(void)
{
	t_btree *tree;

	tree = NULL;
	tree = btree_create_node("test");
	printf("%s\n", tree->item);
	return (0);
}
