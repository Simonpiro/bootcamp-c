/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/26 11:07:31 by spiro             #+#    #+#             */
/*   Updated: 2016/08/26 11:09:24 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdio.h>

void		btree_apply_suffix(t_btree *root, void (*applyf)(void *));

void			ft_test(void *item)
{
	printf("%s\n", item);
}

int	ft_strcmp(char *s1, char *s2)
{
	int				i;
	unsigned char	a;
	unsigned char	b;

	i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		a = s1[i];
		b = s2[i];
		if (a > b || b == '\0')
			return (a - b);
		else if (a < b)
			return (a - b);
		i++;
	}
	return (0);
}

t_btree		*ft_btree_insert(t_btree *root, void *item)
{
	if (root == NULL)
		root = btree_create_node(item);
	else if (ft_strcmp(item, root->item) < 0)
		root->left = ft_btree_insert(root->left, item);
	else
		root->right = ft_btree_insert(root->right,item);
	return (root);
}

int			main(void)
{
	t_btree *tree;

	tree = NULL;
	tree = ft_btree_insert(tree, "F");
	tree = ft_btree_insert(tree, "D");
	tree = ft_btree_insert(tree, "J");
	tree = ft_btree_insert(tree, "B");
	tree = ft_btree_insert(tree, "E");
	tree = ft_btree_insert(tree, "A");
	tree = ft_btree_insert(tree, "C");
	tree = ft_btree_insert(tree, "G");
	tree = ft_btree_insert(tree, "K");
	tree = ft_btree_insert(tree, "I");
	btree_apply_suffix(tree, &ft_test);
	return (0);
}
