/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/26 11:07:31 by spiro             #+#    #+#             */
/*   Updated: 2016/08/26 11:09:24 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdio.h>

void		btree_insert_data(t_btree **root, void *item, int (*cmpf)(void *, void *));
void		btree_apply_infix(t_btree *root, void (*applyf)(void *));

void			ft_test(void *item)
{
	printf("%s\n", item);
}

int	ft_strcmp(void *s1, void *s2)
{
	int				i;
	unsigned char	*a;
	unsigned char	*b;

	i = 0;
	a = s1;
	b = s2;
	while (a[i] != '\0' || b[i] != '\0')
	{
		if (a[i] > b[i] || b[i] == '\0')
			return (a[i] - b[i]);
		else if (a[i] < b[i])
			return (a[i] - b[i]);
		i++;
	}
	return (0);
}

/*t_btree		*ft_btree_insert(t_btree *root, void *item)
{
	if (root == NULL)
		root = btree_create_node(item);
	else if (ft_strcmp(item, root->item) < 0)
		root->left = ft_btree_insert(root->left, item);
	else
		root->right = ft_btree_insert(root->right,item);
	return (root);
}*/

int			main(void)
{
	t_btree *tree;

	tree = NULL;
	btree_insert_data(&tree, "F", &ft_strcmp);
	btree_insert_data(&tree, "D", &ft_strcmp);
	btree_insert_data(&tree, "J", &ft_strcmp);
	btree_insert_data(&tree, "B", &ft_strcmp);
	btree_insert_data(&tree, "E", &ft_strcmp);
	btree_insert_data(&tree, "A", &ft_strcmp);
	btree_insert_data(&tree, "C", &ft_strcmp);
	btree_insert_data(&tree, "G", &ft_strcmp);
	btree_insert_data(&tree, "K", &ft_strcmp);
	btree_insert_data(&tree, "I", &ft_strcmp);
	btree_apply_infix(tree, &ft_test);
	return (0);
}
