/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/26 11:07:31 by spiro             #+#    #+#             */
/*   Updated: 2016/08/26 11:09:24 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"
#include <stdio.h>

void			*btree_search_item(t_btree *root, void *data_ref, int (*cmpf)(void *, void *));

void			ft_test(void *item)
{
	printf("%s\n", item);
}

int	ft_strcmp(void *s1, void *s2)
{
	int				i;
	unsigned char	*a;
	unsigned char	*b;

	i = 0;
	a = s1;
	b = s2;
	while (a[i] != '\0' || b[i] != '\0')
	{
		if (a[i] > b[i] || b[i] == '\0')
			return (a[i] - b[i]);
		else if (a[i] < b[i])
			return (a[i] - b[i]);
		i++;
	}
	return (0);
}

t_btree		*ft_btree_insert(t_btree *root, void *item)
{
	if (root == NULL)
		root = btree_create_node(item);
	else if (ft_strcmp(item, root->item) < 0)
		root->left = ft_btree_insert(root->left, item);
	else
		root->right = ft_btree_insert(root->right,item);
	return (root);
}

int			main(void)
{
	t_btree *tree;
	t_btree *nemo;

	tree = NULL;
	tree = ft_btree_insert(tree, "F");
	tree = ft_btree_insert(tree, "D");
	tree = ft_btree_insert(tree, "J");
	tree = ft_btree_insert(tree, "B");
	tree = ft_btree_insert(tree, "E");
	tree = ft_btree_insert(tree, "A");
	tree = ft_btree_insert(tree, "C");
	tree = ft_btree_insert(tree, "G");
	tree = ft_btree_insert(tree, "K");
	tree = ft_btree_insert(tree, "I");
	nemo = btree_search_item(tree, "A", &ft_strcmp);
	if(nemo)
		printf("%s", nemo->item);
	else
		printf("not found");
	return (0);
}
