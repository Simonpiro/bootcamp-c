/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_search_item.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/26 14:08:50 by spiro             #+#    #+#             */
/*   Updated: 2016/08/26 14:09:07 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void		*btree_search_item(t_btree *root, void *data_ref, int (*cmpf)(void *, void *))
{
	t_btree	*tmp;

	if (root != NULL)
	{
		btree_search_item(root->left, data_ref, cmpf);
		if (cmpf(root->item, data_ref) == 0)
			return(root);
		btree_search_item(root->right, data_ref, cmpf);
	}
	return (NULL);
}
