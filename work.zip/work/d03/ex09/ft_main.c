/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/12 13:49:13 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int x);
int		ft_sort_integer_table(int *tab, int size);
void	ft_putchar(char v);

int main()
{
	int table[] = {5, 3, 9, 1, 2, -1, 0, 4, 6};
	int x;

	x = 0;
	ft_sort_integer_table(table, 9);
	while(x < 9)
	{
		ft_putnbr(table[x]);
	x++;
	}
	ft_putchar('\n');
	
	return(0);
}
