/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 22:55:01 by spiro             #+#    #+#             */
/*   Updated: 2016/08/11 23:11:53 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strrev(char *str)
{
	int length;
	int x;

	length = 0;
	x = 0;
	while (str[length] != '\0')
		length++;
	while (x < length / 2)
	{
		str[length] = str[x];
		str[x] = str[length - x - 1];
		str[length - x - 1] = str[length];
		x++;
	}
	str[length] = '\0';
	return (str);
}
