/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/13 09:14:06 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strrev(char *str);
char	ft_putchar(char c);
void	ft_putstr(char *x);

int main()
{
	char a[] = "abcdqwe";
	char *b;

	b = ft_strrev(a);
	ft_putstr(b);
	//ft_putchar(b[0]);
	ft_putchar('\n');
	return(0);
}
