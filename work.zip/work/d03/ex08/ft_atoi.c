/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/12 10:16:27 by spiro             #+#    #+#             */
/*   Updated: 2016/08/12 12:58:52 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_atoi(char *str)
{
	int i;
	int number;
	int sign;

	i = 0;
	sign = 1;
	number = 0;
	while (str[i] != '\0')
	{
		if ((str[i] >= 48 && str[i] < 58) || str[0] == 45)
		{
			if (str[i] != 45)
				number = 10 * number + (str[i] - 48);
		}
		else
			break ;
		i++;
	}
	if (str[0] == 45)
	{
		sign = (-1);
	}
	return (number * sign);
}
