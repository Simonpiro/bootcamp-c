/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/12 12:49:36 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int x);
int		ft_atoi(char *str);
void	ft_putchar(char v);

int main()
{
	char a[] = "abcd";
	char *c = "540321";
	int nbr1;
	int nbr2;
	int nbr3;
	char *d = "-2147483648";

	nbr1 = 0;
	nbr2 = 0;
	nbr3 = 0;
	nbr1 = ft_atoi(a);
	ft_putnbr(nbr1);
	ft_putchar('\n');
	nbr2 = ft_atoi(c);
	ft_putnbr(nbr2);
	ft_putchar('\n');
	nbr3 = ft_atoi(d);
	ft_putnbr(nbr3);
	return(0);
}
