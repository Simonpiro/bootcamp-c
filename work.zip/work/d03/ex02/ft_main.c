/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/11 15:14:11 by spiro             #+#    #+#             */
/*   Updated: 2016/08/11 15:47:25 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putnbr(int i);
void	ft_putchar(char c);
void	ft_swap(int *a, int *b);

int main()
{
	int a;
	int b;
	
	a = 4;
	b = 2;
	ft_putnbr(a);
	ft_putnbr(b);
	ft_putchar('\n');
	ft_swap(&a, &b);
	ft_putnbr(a);
	ft_putnbr(b);
	return(0);
}
