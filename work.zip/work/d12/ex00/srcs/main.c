/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 08:33:04 by spiro             #+#    #+#             */
/*   Updated: 2016/08/23 08:45:17 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_print_file(int fd)
{
	int		ret;
	char	buf[BUF_SIZE + 1];

	while (1)
	{
		ret = read(fd, buf, BUF_SIZE);
		buf[ret] = '\0';
		if (ret == 0)
			return (0);
		ft_putstr(buf);
	}
	return (1);
}

int		main(int argc, char **argv)
{
	int		fd;

	if (argc == 2)
	{
		fd = open(argv[1], O_RDONLY);
		if (fd == -1)
		{
			write(2, "open() error\n", 13);
			return (0);
		}
		ft_print_file(fd);
		if (close(fd) == -1)
		{
			write(2, "close() error\n", 14);
			return (0);
		}
	}
	else if (argc == 1)
		write(2, "File name missing.\n", 19);
	else
		write(2, "Too many arguments.\n", 20);
	return (0);
}
