/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 08:33:04 by spiro             #+#    #+#             */
/*   Updated: 2016/08/23 08:45:17 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_print_error(char *arg)
{
	if (errno == 13)
	{
		ft_putstr(2, ft_progname());
		ft_putstr(2, ": ");
		ft_putstr(2, arg);
		ft_putstr(2, ": Permission denied\n");
	}
	else if (errno == 21)
	{
		ft_putstr(2, ft_progname());
		ft_putstr(2, ": ");
		ft_putstr(2, arg);
		ft_putstr(2, ": Is a directory\n");
	}
	else
	{
		ft_putstr(2, ft_progname());
		ft_putstr(2, ": ");
		ft_putstr(2, arg);
		ft_putstr(2, ": No such file or directory\n");
	}
}

int		ft_print_file(int fd, char *arg)
{
	int		ret;
	char	buf[BUF_SIZE + 1];

	if (fd == -1)
	{
		ft_print_error(arg);
		return (0);
	}
	while (1)
	{
		ret = read(fd, buf, BUF_SIZE);
		buf[ret] = '\0';
		if (ret == 0)
			return (0);
		else if (ret == -1)
		{
			ft_print_error(arg);
			return (0);
		}
		ft_putstr(1, buf);
	}
	if (close(fd) == -1)
		write(2, "close() error\n", 14);
	return (1);
}

void	ft_print_cli(void)
{
	char	buf[BUF_SIZE + 1];
	int		ret;

	while ((ret = read(0, buf, BUF_SIZE + 1)))
		write(1, buf, ret);
}

int		main(int argc, char **argv)
{
	int		fd;
	int		i;

	i = 1;
	ft_set_progname(argv[0]);
	if (argc == 1 || argv[1][0] == '-')
		ft_print_cli();
	else if (argc > 1)
	{
		while (i < argc)
		{
			if (argv[i][0] == '-')
				ft_print_cli();
			else
			{
				fd = open(argv[i], O_RDONLY);
				ft_print_file(fd, argv[i]);
			}
			i++;
		}
	}
	else
		write(2, "Too many arguments.\n", 20);
	return (0);
}
