#!/bin/sh

TMPDIRNAME=$(mktemp -d)
BINARYNAME=$RANDOM
trap "rm -rf $TMPDIRNAME" EXIT

cd ..
make all || exit 1
cp ft_cat $TMPDIRNAME/$BINARYNAME
cd $TMPDIRNAME

GREEN=$(printf "\e[32;1m")
RED=$(printf "\e[31;1m")
RESET=$(printf "\e[m")

printf "stdin" > input
printf "stdin" > expect.out
printf "" > expect.err

CMD="./$BINARYNAME"

echo $CMD
$CMD >user.out 2>user.err <input
echo diff -U 3 user.out expect.out
diff -U 3 user.out expect.out 
OUTEXIT=$?
echo diff -U 3 user.err expect.err
diff -U 3 user.err expect.err
ERREXIT=$?
( exit $(echo $OUTEXIT + $ERREXIT | bc) ) && echo "${GREEN}Diff [OK]$RESET" || echo "${RED}Diff [KO]$RESET"
