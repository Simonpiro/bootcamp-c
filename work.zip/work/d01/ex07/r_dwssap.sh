#!/bin/bash

cat /etc/passwd | grep -v "#" | awk 'NR%2==0' | rev | grep -o '[^:]*$'  | sort -r | awk -v low="$FT_LINE1" -v high="$FT_LINE2" 'NR >= low && NR <=high' | xargs | sed -e 's/ /, /g' | sed -e 's/$/./' | tr -d '\n'
