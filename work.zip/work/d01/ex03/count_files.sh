#!/bin/bash

find  . -name "*" | wc | awk '{print $1}'
