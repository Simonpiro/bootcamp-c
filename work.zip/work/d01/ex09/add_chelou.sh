#!/bin/bash

A=$( echo $FT_NBR1 | tr \'\\'\"'\?\! 01234)
B=$( echo $FT_NBR2 | tr mrdoc 01234)
echo "ibase=5;obase=D;$A + $B" | bc | tr 0123456789ABC gtaio\ luSnemf
