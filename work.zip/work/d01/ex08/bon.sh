#!/bin/bash

ldapsearch -Q "uid=*" cn | grep "^cn:" | cut -c5- | grep "mon" | wc | awk '{print $1}'
