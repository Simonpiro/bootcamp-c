#!/bin/bash

echo $FT_USER | groups | sed "s/ /,/g" | tr -d '\n'
