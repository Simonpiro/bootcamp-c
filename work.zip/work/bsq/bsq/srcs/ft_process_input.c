/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_process_input.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/29 15:30:39 by spiro             #+#    #+#             */
/*   Updated: 2016/08/29 15:30:44 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		*ft_init_lengths(int *lengths)
{
	lengths[0] = 0;
	lengths[1] = 0;
	lengths[2] = 0;
	return (lengths);
}

int		*ft_get_lengths(int fd)
{
	char		buf;
	int			*lengths;
	int			length;

	length = 0;
	lengths = (int*)malloc(sizeof(int) * 3);
	lengths = ft_init_lengths(lengths);
	while (read(fd, &buf, 1) != 0)
	{
		if (buf != '\n' && lengths[2] == 0)
			lengths[0]++;
		else if (buf != '\n' && lengths[2] == 1)
			lengths[1]++;
		else if (buf != '\n')
			length++;
		else if (buf == '\n')
		{
			lengths[2]++;
			if ((length != lengths[1] && lengths[2] != 2))
				return (0);
			length = 0;
		}
	}
	return (lengths);
}

int		ft_validate_input(int fd, int *lengths)
{
	char	buf;
	int		count;
	int		lines;

	count = 0;
	lines = 0;
	while (1)
	{
		if (!(read(fd, &buf, 1)))
			return (lines == (lengths[2] - 1) ? 1 : 0);
		if (count < lengths[0] - 3)
			lines = 10 * lines + (buf - 48);
		if (count == lengths[0] - 3)
			g_inf[0] = buf;
		else if (count == lengths[0] - 2)
			g_inf[1] = buf;
		else if (count == lengths[0] - 1)
			g_inf[2] = buf;
		if (count > lengths[0] && buf != g_inf[0] &&
			buf != g_inf[1] && buf != '\n')
			return (0);
		count++;
	}
}

char	**ft_create_map(int fd, int *lengths)
{
	char	**map;
	char	buf;
	int		i;
	int		j;

	i = 0;
	j = 0;
	buf = 0;
	while (buf != '\n')
		read(fd, &buf, 1);
	map = (char**)malloc(sizeof(char*) * lengths[2]);
	while (i < (lengths[2] - 1))
	{
		map[i] = (char*)malloc(sizeof(char) * (lengths[1] + 1));
		while (j < (lengths[1]))
		{
			read(fd, &buf, 1);
			if (buf != '\n')
				map[i][j++] = buf;
		}
		map[i++][j] = '\0';
		j = 0;
	}
	map[i] = 0;
	return (map);
}

int		ft_process_input(char *file)
{
	int		fd;
	int		*lengths;
	char	**map;

	fd = ft_open_file(file);
	lengths = ft_get_lengths(fd);
	if (lengths == 0 || lengths[0] < 4)
	{
		write(2, "map error\n", 10);
		return (0);
	}
	ft_close_file(fd);
	fd = ft_open_file(file);
	if (ft_validate_input(fd, lengths) == 0)
	{
		write(2, "map error\n", 10);
		return (0);
	}
	ft_close_file(fd);
	fd = ft_open_file(file);
	map = ft_create_map(fd, lengths);
	ft_close_file(fd);
	ft_bsq(map, lengths);
	free(lengths);
	return (0);
}
