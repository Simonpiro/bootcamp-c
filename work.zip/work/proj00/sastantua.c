/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sastantua.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/14 07:46:09 by spiro             #+#    #+#             */
/*   Updated: 2016/08/14 22:04:01 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char x);
void	ft_putnbr(int y);

int	ft_calculate_length(int level)
{
	int length;
	int i;

	length = 7 + (12 * (level-1));
	i = 1;
	while(i < level)
	{ 
		//length = length + (2 * (level - (i +1) ));
		//i++;
	//}
	
	if (level > 3 && level % 2 != 0)
	{
		length += (level);
	}
	else
		length += level;
	i++;
}
	return (length);	
}

void	ft_print_line(int line_position, int level, int size, int offset)
{
	int length;
	int i;
	int stars;
	int spaces;
	int increment;

	i = 0;
	length = ft_calculate_length(level) + offset;
	spaces = line_position -1 + offset;
	stars = length - 2 - (spaces*2) + offset;
		while (i < length)
		{
			if (spaces > 0)
			{
				ft_putchar(' ');
				spaces--;
			}
			else if (spaces == 0)
			{
				ft_putchar('/');
				spaces--;
			}
			else if(stars > 0)
			{
				ft_putchar('*');
				stars --;
			}
			else if (stars == 0)
			{
				ft_putchar('\\');
				stars--;
			}
			i++;
		}
		ft_putchar('\n');
}

void	ft_print_level(int level, int size,int offset)
{
	int lines;

	lines  = level + 2;
	while (lines > 0)
	{
		ft_print_line(lines, level, size, offset);
		lines--;
	}
}

void	sastantua(int size)
{
	//int level;

	//level = 1;
	//while (level<=size)
	//{	
	//	ft_print_level(level, size, (size-level)*6);
	//level++;
	//}
	ft_print_level(1,size,57);
	ft_print_level(2,size,50);
	ft_print_level(3,size,42);
	ft_print_level(4,size,33);
	ft_print_level(5,size,23);
	ft_print_level(6,size,12);
	ft_print_level(7,size,0);
}

int	main(void)
{
	sastantua(4);
	return (0);
}
