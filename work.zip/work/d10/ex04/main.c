/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 15:18:49 by spiro             #+#    #+#             */
/*   Updated: 2016/08/22 15:32:50 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_any(char **tab, int (*f)(char*));

int		func(char *c)
{
	int i = 0;

	while(c[i] != '\0')
	{
		if(c[i] == 'o')
			return (0);
		i++;
	}
	return (0);
}

int		main()
{
	char *array[3] = {"test", "notest" , 0};
	int	i;
	int (*p)(char*);

	p = &func;
	i = 0;
	while(i<3)
	{
		printf("%d" , ft_any(array , p));
		i++;
	}
	return (0);
}
