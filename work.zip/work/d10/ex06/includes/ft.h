/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/20 10:49:32 by spiro             #+#    #+#             */
/*   Updated: 2016/08/22 11:21:25 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <unistd.h>

int		ft_atoi(char *str);
int		ft_add(int a, int b);
void	ft_putchar(char c);
void	ft_putnbr(int nb);
void	ft_putstr(char *c);
int		ft_red(int a, int b);
int		ft_divide(int a, int b);
int		ft_multiply(int a, int b);
int		ft_mod(int a, int b);
#endif
