/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/10 20:41:04 by spiro             #+#    #+#             */
/*   Updated: 2016/08/11 14:56:06 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_print_exception(int exc)
{
	if (exc == -2147483648)
	{
		ft_putchar('-');
		ft_putchar('2');
		ft_putchar('1');
		ft_putchar('4');
		ft_putchar('7');
		ft_putchar('4');
		ft_putchar('8');
		ft_putchar('3');
		ft_putchar('6');
		ft_putchar('4');
		ft_putchar('8');
	}
	else if (exc < 0)
	{
		ft_putchar('-');
	}
	return (exc *= -1);
}

int		ft_set_divider(int nb)
{
	int divider;

	divider = 1;
	while (nb >= 10)
	{
		nb /= 10;
		divider *= 10;
	}
	return (divider);
}

void	ft_putnbr(int nb)
{
	int divider;

	if (nb < 0)
	{
		nb = ft_print_exception(nb);
	}
	divider = ft_set_divider(nb);
	while (divider > 0)
	{
		if (nb / divider >= 0)
		{
			ft_putchar(nb / divider + 48);
			nb = nb % divider;
		}
		divider /= 10;
	}
}
