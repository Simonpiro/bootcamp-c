/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ops.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 08:59:07 by spiro             #+#    #+#             */
/*   Updated: 2016/08/23 09:00:31 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_add(int a, int b)
{
	ft_putnbr(a + b);
	return (0);
}

int		ft_red(int a, int b)
{
	ft_putnbr(a - b);
	return (0);
}

int		ft_divide(int a, int b)
{
	if (b == 0)
	{
		ft_putstr("Stop: division by zero");
		return (0);
	}
	else
		ft_putnbr(a / b);
	return (0);
}

int		ft_multiply(int a, int b)
{
	ft_putnbr(a * b);
	return (0);
}

int		ft_mod(int a, int b)
{
	if (b == 0)
	{
		ft_putstr("Stop: modulo by zero");
		return (0);
	}
	else
		ft_putnbr(a % b);
	return (0);
}
