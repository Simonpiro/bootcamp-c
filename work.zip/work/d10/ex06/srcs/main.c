/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/23 08:33:04 by spiro             #+#    #+#             */
/*   Updated: 2016/08/23 08:45:17 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_do_op(int a, int b, char op)
{
	int		(*p)(int, int);

	p = 0;
	if (op == '+')
		p = &ft_add;
	else if (op == '-')
		p = &ft_red;
	else if (op == '/')
		p = &ft_divide;
	else if (op == '*')
		p = &ft_multiply;
	else if (op == '%')
		p = &ft_mod;
	else
	{
		ft_putnbr(0);
		ft_putchar('\n');
		return (0);
	}
	p(a, b);
	ft_putchar('\n');
	return (0);
}

int		main(int argc, char **argv)
{
	int		a;
	int		b;
	char	op;

	if (argc == 4)
	{
		a = ft_atoi(argv[1]);
		b = ft_atoi(argv[3]);
		op = *argv[2];
		ft_do_op(a, b, op);
	}
	return (0);
}
