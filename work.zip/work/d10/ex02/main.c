/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 15:18:49 by spiro             #+#    #+#             */
/*   Updated: 2016/08/22 15:32:50 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		*ft_map(int *tab, int length, int (*f)(int a));

int		power(int x)
{
	return (x*x);
}

int		main()
{
	int numbers[3] = {1, 2, 3};
	int	i;
	int *numbers2;
	int (*p)(int);

	p = &power;
	i = 0;
	numbers2 = ft_map(numbers, 3, p);
	while(i<3)
	{
		printf("%d" , numbers2[i]);
		i++;
	}
	return (0);
}
