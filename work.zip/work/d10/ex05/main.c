/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 15:18:49 by spiro             #+#    #+#             */
/*   Updated: 2016/08/22 18:54:25 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		ft_is_sort(int *tab, int length, int (*f)(int, int));

int		power(int x, int y)
{
	if(x < y)
		return(-1);
	else if (x > y)
		return (1);
	else
		return (0);
}

int		main()
{
	int numbers[] = {1, 4, 3};
	int	i;
	int numbers2;
	int (*p)(int, int);

	p = &power;
	i = 0;
	numbers2 = ft_is_sort(numbers, 3, p);
	while(i<3)
	{
		printf("%d" , numbers2);
		i++;
	}
	return (0);
}
