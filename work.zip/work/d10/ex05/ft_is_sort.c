/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spiro <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/22 18:09:40 by spiro             #+#    #+#             */
/*   Updated: 2016/08/22 19:08:30 by spiro            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int		i;
	int		trend;

	i = 0;
	trend = 0;
	while (i < length - 1)
	{
		if (f(tab[i], tab[i + 1]) > 0)
		{
			if (trend == -1)
				return (0);
			trend = 1;
		}
		else if (f(tab[i], tab[i + 1]) < 0)
		{
			if (trend == 1)
				return (0);
			trend = -1;
		}
		i++;
	}
	return (1);
}
